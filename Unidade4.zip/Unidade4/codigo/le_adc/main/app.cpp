/* Hello World Example

   This example code is in the Public Domain (or CC0 licensed, at your option.)

   Unless required by applicable law or agreed to in writing, this
   software is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
   CONDITIONS OF ANY KIND, either express or implied.
*/
#include <stdio.h>
#include <string.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_system.h"
#include "esp_spi_flash.h"
#include "driver/adc.h"
#include <inttypes.h> 
#include "serial.h"



 
extern "C" void app_main() ;

void app_main()
{
	uint16_t valor;
	adc_config_t configuracao_ADC;
	
	configuracao_ADC.mode = ADC_READ_TOUT_MODE;
	configuracao_ADC.clk_div = 8;
	
	ESP_ERROR_CHECK(adc_init(&configuracao_ADC));

	serial.begin(9600);
	float temperatura=3.14;

	int inteiro;
	int decimal;

	while(1)
    	{

        	vTaskDelay(500 / portTICK_PERIOD_MS);
		adc_read(&valor);
		temperatura = (valor/ 1024.0)*330;
		inteiro = temperatura;
		decimal = (temperatura - inteiro) * 100;

		printf("valor=%d   temp=%d.%d \n",valor,inteiro,decimal);
		
		
	
	}

}
