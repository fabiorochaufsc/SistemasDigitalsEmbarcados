# UNIDADE 4: Interface com sistemas analógicos  [8 horas-aula]

* Conversores AD e DA
* Sensores analógicos (temperatura, luz, cor)
* Experiências práticas com sistemas analógicos, captura e transmissão de dados
* Experiências práticas com saída analógica,  gerador de funções



